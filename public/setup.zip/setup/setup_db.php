<form method="post" action="/setup/post/send_db.php">
    <input type="text" name="dbname" placeholder="Database name" required/><br>
    <input type="text" name="host" placeholder="Host (ex. domain.com)" required/><br>
    <input type="text" name="username" placeholder="Username" required/><br>
    <input type="password" name="password" placeholder="Password"/><br>
    <button type="submit">Set configuration</button>
</form>