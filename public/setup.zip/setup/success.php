<div class="column">
    <h1>You have succesfully installed JJMVC</h1>
    <p>After this request JJMVC should remove setup folder automatically. However you should check that setup folder is deleted from public folder. If setup folder is not removed we recommend to remove it manually as it could be security issue. You can go to frontpage by <a href="/">clicking here.</a></p>
</div>